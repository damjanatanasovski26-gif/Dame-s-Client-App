<?php

/**
 * Plugin Name: Bit Assist
 * Plugin URI:  https://bitapps.pro/bit-assist
 * Description: WhatsApp,Facebook Messenger chat, click to chat Live Chat Widget,Call button & 30+ social chat support button for customer support with sticky chat button
 * Version:     1.6.0
 * Author:      Bit Assist - Click to Chat Widget Live Chat Support Chat Button
 * Author URI:  https://bitapps.pro
 * Text Domain: bit-assist
 * Requires PHP: 7.4
 * Requires WP: 5.1
 * Domain Path: /languages
 * License: gpl2+
 */
require_once plugin_dir_path(__FILE__) . 'backend/bootstrap.php';
